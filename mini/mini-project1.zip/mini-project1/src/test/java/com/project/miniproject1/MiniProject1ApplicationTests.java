package com.project.miniproject1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MiniProject1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
